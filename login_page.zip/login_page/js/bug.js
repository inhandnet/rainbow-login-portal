/**
 * Created by kkzhou on 2014/12/5.
 */
callback_get_static_param({
    loginMethod:"weibo,qq,sms,one-click"
});