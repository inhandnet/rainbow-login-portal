/**
 * Created by kkzhou on 14-12-3.
 */
var a=1;
function test(b,c){
    console.log(b);
}